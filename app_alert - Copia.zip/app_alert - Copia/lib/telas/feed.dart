import 'package:flutter/material.dart';

class Feed extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Tela do Portal', style: TextStyle(fontSize: 24)),
    );
  }
}