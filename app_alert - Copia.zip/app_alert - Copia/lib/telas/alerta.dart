import 'package:flutter/material.dart';

class Alerta extends StatefulWidget {
  @override
  _AlertaState createState() => _AlertaState();
}

class _AlertaState extends State<Alerta> {
  DateTime? _selectedDate;

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (pickedDate != null && pickedDate != _selectedDate) {
      setState(() {
        _selectedDate = pickedDate;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Fazer Alerta')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.image, size: 100, color: Colors.orange),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: null, //nao funciona ainda
              child: Text('Tirar Foto'),
            ),
            const SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(labelText: 'Título'),
            ),
            const SizedBox(height: 20.0,),
             TextField(
              decoration: InputDecoration(labelText: 'Texto'),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                GestureDetector(
                  onTap: () => _selectDate(context),
                  child: Column(
                    children: [
                      Icon(Icons.calendar_today, size: 30),
                      if (_selectedDate != null)
                        Text(
                          '${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}',
                          style: TextStyle(fontSize: 12),
                        )
                    ],
                  ),
                ),
                Icon(Icons.location_on, size: 30),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 32.0),
        child: ElevatedButton(
          onPressed: () {
            // Implementar ação para enviar os dados
          },
          style: ElevatedButton.styleFrom(
            minimumSize: Size(double.infinity, 50),
          ),
          child: Text('Fazer Alerta'),
        ),
      ),
    );
  }
}
