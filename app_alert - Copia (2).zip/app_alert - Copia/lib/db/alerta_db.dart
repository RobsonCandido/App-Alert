import 'package:app_alert/model/alertaifpr.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AlertaDb {
  final String _nomeTabela = "contato";

  static final AlertaDb _alertaDb = AlertaDb._internal();
  Database? _db;

  factory AlertaDb() {
    return _alertaDb;
  }

  AlertaDb._internal();

  Future<Database> get db async {
    if (_db != null) {
      return _db!;
    } else {
      _db = await inicializarDB();
      return _db!;
    }
  }

  Future<void> _onCreate(Database db, int version) async {
    String sql = '''
      CREATE TABLE $_nomeTabela (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT,
        telefone TEXT,
        data TEXT,
        descricao TEXT,
        registroacademico TEXT
      )
    ''';
    await db.execute(sql);
    print("Tabela criada com sucesso: $_nomeTabela");
  }

  Future<Database> inicializarDB() async {
    final caminhoBancoDados = join(await getDatabasesPath(), "ifpralert.db");
    return await openDatabase(
      caminhoBancoDados,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<int> enviarAlerta(Alertaifpr contato) async {
    var bancoDados = await db;
    int resultado = await bancoDados.insert(_nomeTabela, contato.toMap());
    return resultado;
  }


  Future<int> atualizarAlerta(Alertaifpr alerta) async {
  var bancoDados = await db;
  return await bancoDados.update(
    _nomeTabela,
    alerta.toMap(),
    where: "id = ?",
    whereArgs: [alerta.id],
  );
}

  Future<int> deletarAlerta(int id) async {
    var bancoDados = await db;
    return await bancoDados.delete(
      _nomeTabela,
      where: "id = ?",
      whereArgs: [id],
    );
  }

  Future<List<Map<String, dynamic>>> recuperarContatos() async {
    var bancoDados = await db;
    return await bancoDados.query(_nomeTabela, orderBy: "nome");
  }

  Future<Map<String, dynamic>?> recuperarContato(int id) async {
    var bancoDados = await db;
    var resultado = await bancoDados.query(
      _nomeTabela,
      where: "id = ?",
      whereArgs: [id],
    );
    return resultado.isNotEmpty ? resultado.first : null;
  }
}
