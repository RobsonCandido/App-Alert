import 'package:app_alert/db/alerta_db.dart';
import 'package:flutter/material.dart';
import 'package:app_alert/model/alertaifpr.dart';


class Alerta extends StatefulWidget {
  @override
  _AlertaState createState() => _AlertaState();
}

class _AlertaState extends State<Alerta> {
  DateTime? _selectedDate;
  final _tituloController = TextEditingController();
  final _descricaoController = TextEditingController();
  final _telefoneController = TextEditingController();
  final _raController = TextEditingController();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (pickedDate != null && pickedDate != _selectedDate) {
      setState(() {
        _selectedDate = pickedDate;
      });
    }
  }

  Future<void> _fazerAlerta() async {
    if (_tituloController.text.isEmpty ||
        _descricaoController.text.isEmpty ||
        _telefoneController.text.isEmpty ||
        _raController.text.isEmpty ||
        _selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Por favor, preencha todos os campos!')),
      );
      return;
    }

    Alertaifpr alerta = Alertaifpr(
      nome: _tituloController.text,
      descricao: _descricaoController.text,
      telefone: _telefoneController.text,
      data: _selectedDate!,
      ra: _raController.text,
    );

    int resultado = await AlertaDb().enviarAlerta(alerta);

    if (resultado > 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Alerta salvo com sucesso!')),
      );
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao salvar o alerta.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Fazer Alerta')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.image, size: 100, color: Colors.orange),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: null, // Não implementado ainda
                child: Text('Tirar Foto'),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _tituloController,
                decoration: InputDecoration(labelText: 'Título'),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _descricaoController,
                decoration: InputDecoration(labelText: 'Texto'),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _telefoneController,
                decoration: InputDecoration(labelText: 'Telefone'),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _raController,
                decoration: InputDecoration(labelText: 'Registro Acadêmico (RA)'),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  GestureDetector(
                    onTap: () => _selectDate(context),
                    child: Column(
                      children: [
                        Icon(Icons.calendar_today, size: 30),
                        if (_selectedDate != null)
                          Text(
                            '${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}',
                            style: TextStyle(fontSize: 12),
                          )
                      ],
                    ),
                  ),
                  Icon(Icons.location_on, size: 30),
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 32.0),
        child: ElevatedButton(
          onPressed: _fazerAlerta,
          style: ElevatedButton.styleFrom(
            minimumSize: Size(double.infinity, 50),
          ),
          child: Text('Fazer Alerta'),
        ),
      ),
    );
  }
}
