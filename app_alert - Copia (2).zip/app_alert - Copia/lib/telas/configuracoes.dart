import 'package:flutter/material.dart';

class Configuracoes extends StatefulWidget {
  @override
  _ConfiguracoesScreenState createState() => _ConfiguracoesScreenState();
}

class _ConfiguracoesScreenState extends State<Configuracoes> {
  bool notificacoesAtivadas = false;
  double volumeNotificacao = 0.5;
  String meioDeComunicacao = "Email";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Settings"),
        backgroundColor: Colors.orange,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Ativar Notificações", style: TextStyle(fontSize: 18)),
                Switch(
                  value: notificacoesAtivadas,
                  onChanged: (bool value) {
                    setState(() {
                      notificacoesAtivadas = value;
                    });
                  },
                ),
              ],
            ),
            SizedBox(height: 20),
            Text("Volume da Notificação", style: TextStyle(fontSize: 18)),
            Slider(
              value: volumeNotificacao,
              min: 0.0,
              max: 1.0,
              divisions: 10,
              label: (volumeNotificacao * 100).toInt().toString() + "%",
              onChanged: notificacoesAtivadas
                  ? (double value) {
                      setState(() {
                        volumeNotificacao = value;
                      });
                    }
                  : null,
            ),
            SizedBox(height: 20),
            Text("Selecione o meio de comunicação:", style: TextStyle(fontSize: 18)),
            ListTile(
              title: Text("Telefone"),
              leading: Radio<String>(
                value: "Telefone",
                groupValue: meioDeComunicacao,
                onChanged: (String? value) {
                  setState(() {
                    meioDeComunicacao = value!;
                  });
                },
              ),
            ),
            ListTile(
              title: Text("Email"),
              leading: Radio<String>(
                value: "Email",
                groupValue: meioDeComunicacao,
                onChanged: (String? value) {
                  setState(() {
                    meioDeComunicacao = value!;
                  });
                },
              ),
            ),
            SizedBox(height: 20),
            TextField(
              decoration: InputDecoration(
                labelText: meioDeComunicacao == "Telefone"
                    ? "Digite o número de telefone aqui"
                    : "Digite o email aqui",
                border: OutlineInputBorder(),
              ),
              keyboardType: meioDeComunicacao == "Telefone"
                  ? TextInputType.phone
                  : TextInputType.emailAddress,
            ),
            SizedBox(height: 20),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  // Ação ao salvar
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Configurações salvas!")),
                  );
                },
                child: Text("SALVAR"),
              ),
            ),  
          ],
        ),
      ),
    );
  }
}
