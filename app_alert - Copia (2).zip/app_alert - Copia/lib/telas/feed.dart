import 'package:app_alert/db/alerta_db.dart';
import 'package:flutter/material.dart';
import 'package:app_alert/model/alertaifpr.dart';


class Feed extends StatefulWidget {
  @override
  _FeedState createState() => _FeedState();
}

class _FeedState extends State<Feed> {
  late Future<List<Alertaifpr>> _alertas;

  @override
  void initState() {
    super.initState();
    _carregarAlertas();
  }

  void _carregarAlertas() {
    setState(() {
      _alertas = _recuperarAlertas();
    });
  }

  Future<List<Alertaifpr>> _recuperarAlertas() async {
    List<Map<String, dynamic>> alertasMap = await AlertaDb().recuperarContatos();
    return alertasMap.map((map) => Alertaifpr.fromMap(map)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Portal de Alertas')),
      body: FutureBuilder<List<Alertaifpr>>(
        future: _alertas,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Erro ao carregar os alertas.'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Nenhum alerta disponível.'));
          } else {
            List<Alertaifpr> alertas = snapshot.data!;
            return RefreshIndicator(
              onRefresh: () async {
                _carregarAlertas();
              },
              child: ListView.builder(
                itemCount: alertas.length,
                itemBuilder: (context, index) {
                  Alertaifpr alerta = alertas[index];
                  return ListTile(
                    leading: Icon(Icons.warning, color: Colors.orange),
                    title: Text(alerta.nome ?? 'Sem título'),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(alerta.descricao ?? 'Sem descrição'),
                        Text(
                          'Data: ${alerta.data?.day}/${alerta.data?.month}/${alerta.data?.year}',
                        ),
                        Text('RA: ${alerta.ra ?? 'N/A'}'),
                      ],
                    ),
                    isThreeLine: true,
                  );
                },
              ),
            );
          }
        },
      ),
    );
  }
}
