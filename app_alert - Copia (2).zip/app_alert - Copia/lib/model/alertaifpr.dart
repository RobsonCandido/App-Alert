class Alertaifpr {
  int? id;
  String? nome;
  String? telefone;
  DateTime? data;
  String? descricao;
  String? ra;

  Alertaifpr({
    this.id,
    required this.nome,
    required this.telefone,
    required this.data,
    required this.descricao,
    required this.ra,
  });

  Map<String, Object?> toMap() {
    return {
      'id': id,
      'nome': nome,
      'telefone': telefone,
      'data': data?.toIso8601String(),
      'descricao': descricao,
      'registroacademico': ra,
    };
  }

  Alertaifpr.fromMap(Map<String, dynamic> map) {
    id = map['id'] as int?;
    nome = map['nome'] as String?;
    telefone = map['telefone'] as String?;
    data = map['data'] != null ? DateTime.parse(map['data'] as String) : null;
    descricao = map['descricao'] as String?;
    ra = map['registroacademico'] as String?;
  }
}
